package com.daimler.kafka.serializer;

import org.apache.kafka.common.serialization.Serializer;

import com.daimler.kafka.domain.EmployeeV2;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeV2Serializer implements Serializer<EmployeeV2> {

private ObjectMapper mapper=new ObjectMapper();

	@Override
	public byte[] serialize(String topic, EmployeeV2 emp) {
		// TODO Auto-generated method stub
		byte[] array=null;
		try {
			String jsonContent=mapper.writeValueAsString(emp);
			System.out.println("serializing "+jsonContent);
			array=jsonContent.getBytes();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return array;
	}

}
