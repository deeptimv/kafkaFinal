package com.daimler.kafka.stream;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;

import com.daimler.kafka.domain.Employee;
import com.daimler.kafka.serde.EmployeeSerde;

public class EmployeeStreamingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test app");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, EmployeeSerde.class);
        
        Serde<String> stringSerde = Serdes.String();
        Serde<Employee> empSerde=new EmployeeSerde();
        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, Employee> simpleFirstStream = builder.stream("emp-src-topic-input");


        KStream<String,Employee> outputStream=simpleFirstStream.mapValues(e->{
        	System.out.println(e);
        	if(e.getDesignation().equals("Developer")) {
        	
        		return new Employee(e.getId(), e.getName(), "Sr Developer");
        	}
        	else {
        		return e;
        	}
        });
        outputStream.to( "emp-out-topic-output", Produced.with(stringSerde, empSerde));
        

        KafkaStreams kafkaStreams = new KafkaStreams(builder.build(),props);
    
        kafkaStreams.start();
        System.out.println("streaming app started");
        try {
			Thread.sleep(10*60*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

}
