package com.daimler.kafka.stream;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;

import com.daimler.kafka.domain.Employee;
import com.daimler.kafka.domain.EmployeeV2;
import com.daimler.kafka.serde.EmployeeSerde;
import com.daimler.kafka.serde.EmployeeV2Serde;

public class EmpStreamingTestEx2 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test app");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, EmployeeSerde.class);

       

        Serde<String> stringSerde = Serdes.String();
        Serde<Employee> empSerde=new EmployeeSerde();
        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, Employee> simpleFirstStream = builder.stream("emp-src-topic");


        KStream<String,EmployeeV2> outputStream=simpleFirstStream.mapValues(e->{
        	System.out.println(e);
        	EmployeeV2  empV2=new EmployeeV2();
        	empV2.setId(e.getId());
        	empV2.setName(e.getName());
        	if(e.getDesignation().equals("Developer")) {
        	
        		empV2.setDesignation("Sr Developer");
        		empV2.setSalary(40000);
        	}
        	else{
        		empV2.setDesignation(e.getDesignation());
        		empV2.setSalary(30000);
        	}
        	return empV2;
        });
        outputStream.to( "emp-out-topic", Produced.with(stringSerde, new EmployeeV2Serde()));
        

        KafkaStreams kafkaStreams = new KafkaStreams(builder.build(),props);
    
        kafkaStreams.start();
        System.out.println("streaming app started");
        try {
			Thread.sleep(10*60*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

}
