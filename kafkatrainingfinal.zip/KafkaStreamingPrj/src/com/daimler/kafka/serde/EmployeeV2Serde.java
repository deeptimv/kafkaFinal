package com.daimler.kafka.serde;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import com.daimler.kafka.deserializer.EmployeeV2Deserializer;
import com.daimler.kafka.domain.EmployeeV2;
import com.daimler.kafka.serializer.EmployeeV2Serializer;

public class EmployeeV2Serde implements Serde<EmployeeV2>{

	

	@Override
	public Deserializer<EmployeeV2> deserializer() {
		// TODO Auto-generated method stub
		return new EmployeeV2Deserializer();
	}

	@Override
	public Serializer<EmployeeV2> serializer() {
		// TODO Auto-generated method stub
		return new EmployeeV2Serializer();
	}

}
