package com.daimler.kafka.serde;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import com.daimler.kafka.deserializer.EmployeeDeserializer;
import com.daimler.kafka.domain.Employee;
import com.daimler.kafka.serializer.EmployeeSerializer;

public class EmployeeSerde implements Serde<Employee>{

	@Override
	public Serializer<Employee> serializer() {
		// TODO Auto-generated method stub
		return new EmployeeSerializer();
	}

	@Override
	public Deserializer<Employee> deserializer() {
		// TODO Auto-generated method stub
		return new EmployeeDeserializer();
	}

}
