package com.daimler.kafka.deserializer;

import java.io.IOException;

import org.apache.kafka.common.serialization.Deserializer;

import com.daimler.kafka.domain.EmployeeV2;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeV2Deserializer implements Deserializer<EmployeeV2>{

	
	ObjectMapper mapper=new ObjectMapper();
	@Override
	public EmployeeV2 deserialize(String topic, byte[] array) {
		// TODO Auto-generated method stub
		EmployeeV2 employee=null;

			try {
				employee=mapper.readValue(array, EmployeeV2.class);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		return employee;
	}

}
