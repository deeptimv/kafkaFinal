package com.test.training;
import java.io.File;
import java.io.IOException;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;

public class SchemaEvolutionExamples {
    public static void main(String[] args) throws IOException {

        // let's test a backward compatible read

        // we deal with the V1 of our customer
        CustomerV1 customerV1 = new CustomerV1(1001, "akash");
                
        //System.out.println("Customer V1 = " + customerV1.toString());
        Schema customerSChema = SchemaBuilder.record("Customer")
        		  .namespace("com.test.training")
        		  .fields().requiredInt("id").requiredString("name")
        		  .endRecord();
        System.out.println(customerSChema);

        // write it out to a file
       final DatumWriter<CustomerV1> datumWriter = new SpecificDatumWriter<>(CustomerV1.class);
        final DataFileWriter<CustomerV1> dataFileWriter = new DataFileWriter<>(datumWriter);
        dataFileWriter.create(customerSChema, new File("customerV1.avro"));
        dataFileWriter.append(customerV1);
        dataFileWriter.close();
        System.out.println("successfully wrote customerV1.avro");

        // we read it using the v2 schema
        System.out.println("Reading our customerV1.avro with v2 schema");
        final File file = new File("customerv1.avro");
        final DatumReader<CustomerV2> datumReaderV2 = new SpecificDatumReader<>(CustomerV2.class);
        final DataFileReader<CustomerV2> dataFileReaderV2 = new DataFileReader<>(file, datumReaderV2);
        while (dataFileReaderV2.hasNext()) {
            CustomerV2 customerV2read = dataFileReaderV2.next();
            System.out.println("Customer V2 = " + customerV2read.toString());
        }

        System.out.println("Backward schema evolution successful\n\n\n");

        
    }}