package com.daimler.kafka.deserializer;

import java.io.IOException;

import org.apache.kafka.common.serialization.Deserializer;

import com.daimler.kafka.domain.Employee;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeDeserializer implements Deserializer<Employee> {

	private ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public Employee deserialize(String topic, byte[] data) {

		try {
			Employee emp = objectMapper.readValue(data, Employee.class);
			System.out.println("emp is " + emp);
			return emp;
		} catch (JsonParseException e) {

			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

}
