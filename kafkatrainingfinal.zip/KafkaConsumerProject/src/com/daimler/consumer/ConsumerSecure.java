package com.daimler.consumer;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

public class ConsumerSecure {

	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		prop.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		prop.setProperty(ConsumerConfig.GROUP_ID_CONFIG, "test-group");

		KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<String, String>(prop);
		List<String> topicList = new ArrayList<>();
		topicList.add("first-topic");
		kafkaConsumer.subscribe(topicList);

		while (true) {
			ConsumerRecords<String, String> consumerRecords = kafkaConsumer.poll(Duration.ofSeconds(10));

			for (ConsumerRecord<String, String> consumerRecord : consumerRecords) {
				System.out.println("message key :" + consumerRecord.key() + ", valuue :" + consumerRecord.value()
						+ ", partition" + consumerRecord.partition());
			}
		}

	}

}
