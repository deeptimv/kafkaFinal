package com.daimler.consumer;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import com.daimler.kafka.deserializer.EmployeeDeserializer;
import com.daimler.kafka.domain.Employee;

public class ConsumerEmployee {

	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		prop.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, EmployeeDeserializer.class.getName());
		prop.setProperty(ConsumerConfig.GROUP_ID_CONFIG, "test-group");

		KafkaConsumer<String, Employee> kafkaConsumer = new KafkaConsumer<String, Employee>(prop);
		List<String> topicList = new ArrayList<>();
		topicList.add("emp-topic");
		kafkaConsumer.subscribe(topicList);

		while (true) {
			ConsumerRecords<String, Employee> consumerRecords = kafkaConsumer.poll(Duration.ofSeconds(10));

			for (ConsumerRecord<String, Employee> consumerRecord : consumerRecords) {
				System.out.println("message key :" + consumerRecord.key() + ", valuue :"
						+ consumerRecord.value().getId() + ", partition" + consumerRecord.partition());
				System.out.println(consumerRecord.value().getName());
			}
		}

	}

}
