package com.daimler.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

public class SecureSender {

	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		prop.setProperty("security.protocol", "SASL_PLAINTEXT");
		prop.setProperty("sasl.mechanism","PLAIN");
		// ADD -Djava.security.auth.login.config=client-jaas-config.properties in the VM args
		KafkaProducer<String, String> kafkaProducer = new KafkaProducer<String, String>(prop);
		String topic = "first-topic";

		for (int i = 0; i <= 10; i++) {

			ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, "test" + i + "msg",
					"test message new::" + i);
			kafkaProducer.send(record);
		}

		for (int i = 0; i <= 10; i++) {

			ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, "test" + i + "msg",
					"test message new::" + i);
			kafkaProducer.send(record);
		}

		System.out.println("messages sent");
		kafkaProducer.close();
	}

}
