package com.daimler.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class SenderCallBack {

	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		KafkaProducer<String, String> kafkaProducer = new KafkaProducer<String, String>(prop);
		String topic = "first-topic";

		for (int i = 0; i <= 10; i++) {
			System.out.println("sending msg "+i);
			ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, "test" + i + "msg",
					"test message new::" + i);
			kafkaProducer.send(record, new Callback() {

				@Override
				public void onCompletion(RecordMetadata rmd, Exception ex) {
					if (ex == null) {
						System.out.println("message" + record.value() + "delivered at partition :" + rmd.partition()
								+ " with offset " + rmd.offset());
					}
				}
			});
		}

		System.out.println("messages sent");
		kafkaProducer.close();
	}

}
