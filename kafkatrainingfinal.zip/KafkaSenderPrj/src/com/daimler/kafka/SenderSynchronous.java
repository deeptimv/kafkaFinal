package com.daimler.kafka;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class SenderSynchronous {

	
	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		KafkaProducer<String, String> kafkaProducer = new KafkaProducer<String, String>(prop);
		String topic = "first-topic";

		for (int i = 0; i <= 10; i++) {
			System.out.println("sending msg "+i);
			ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, "test" + i + "msg",
					"test message new::" + i);
			Future<RecordMetadata> future = kafkaProducer.send(record);
			
				RecordMetadata rmd;
				try {
					rmd = future.get();
					System.out.println("message delievred at partition "+rmd.partition()+" with offset " + rmd.offset());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
		}

		System.out.println("messages sent");
		kafkaProducer.close();
	}
}
