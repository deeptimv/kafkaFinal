package com.daimler.kafka.serializer;

import org.apache.kafka.common.serialization.Serializer;

import com.daimler.kafka.domain.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeSerializer implements Serializer<Employee>{

	
	private ObjectMapper mapper = new ObjectMapper();
	
	
	@Override
	public byte[] serialize(String topic, Employee data) {
		
		byte[] array= null;
		try {
			String json = mapper.writeValueAsString(data);
			
			
			System.out.println("Serializing   "+json);
			array = json.getBytes();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return array;
	}

}
